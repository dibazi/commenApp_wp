<?php
/*
Plugin Name: commentApp
Description: A custom plugin to save comments and read commente.
Version: 1.0.0
Author: Dibazi Nkulu
Author URI: https://blue.senga-service.com/
License: GPL v2 or later
*/

if(!defined('ABSPATH')){
    exit;
}

class CommentApp{
    
    public function __construct(){
        add_action('init', array($this, 'create_comment'));
        
        add_action('up_enqueue_script', array($this, 'load_assets'));
        
        add_shortcode('comment-form', array($this, 'load_shortcode'));
        
        add_action('wp_footer', array($this, 'load_scripts'));
        
        add_action('rest_api_init', array($this, 'register_rest_api'));
        
        // Register an AJAX action for handling the data insertion
        add_action('wp_ajax_insert_data', 'insert_data_handler');
        add_action('wp_ajax_nopriv_insert_data', 'insert_data_handler');
    }
    
    public function create_comment(){
        $args = array(
            'public'=> true,
            'has_archive' => true,
            'supports'=> array('title'),
            'exclude_from_search' => true,
            'publicly_queriable' => false,
            'capability' => 'manage_options',
            'labels'=> array(
                'name' => 'Comment App',
                'singular_name'=> 'comment form'
                ),
                'menu_icon'=>'dashicons-admin-comments',
      );
      register_post_type('CommentApp', $args);
    }
    
    public function load_assets(){
        
    wp_enqueue_style(
    'style',
    plugin_dir_url(__FILE__).'css/style.css',
    array(),
    1,
    'all'
    );
    
    wp_enqueue_script();
    
    }
    
    public function load_shortcode(){
        ?>
                
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <script src="https://cdn.tailwindcss.com"></script>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <title>Laravel</title>
            <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Numito:wght@400;700&display=swap">
        
            <!-- Fonts -->
            <link rel="preconnect" href="https://fonts.bunny.net">
            <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        
            <!-- Styles -->
            <style>
              body {
                font-family: 'Numito', sans-serif;
              }
            </style>
            <title>Document</title>
        </head>
        <body class="bg-gray-200 p-4">
            <div class="lg:w-2/4 mx-auto py-8 px-6 bg-white rounded-xl">
        
              <h1 class="font-bold text-5xl text-center mb-8">Comment app</h1>
        
              <div class="mb-6">
                <form id="myForm" class="flex flex-col space-y-4">
                    <?php wp_nonce_field('insert_data_nonce', 'nonceField'); ?>
                  <input type="text" id="nameField" name="name" placeholder="Your name" class="py-3 px-4 bg-gray-100 rounded-lg">
                  <textarea class="py-3 px-4 bg-gray-100 rounded-lg" id="postField" name="post" placeholder="Your comment" cols="5" rows="2"></textarea>

                  <button type="submit" class="w-28 py-4 px-8 bg-green-500 text-white rounded-lg">Add</button>
                </form>
              </div>
              <hr>
              <div class="mt-2">
        
                <div class="py-4 flex items-center border-b border-gray-300 py-3">
                  <div class="flex-1 pr-8">
                    <h3 class="text-lg font-semibold">Thony</h3>
                    <p class="text-gray-500">just a test</p>
                  </div>
                  <div class="flex space-x-3">
                    <button class="py-2 px-2 bg-green-500 text-white rounded-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                    </svg>
                    </button>
                    <button class="py-2 px-2 bg-red-500 text-white rounded-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                    </svg>
                    </button>
                  </div>
                </div>
                
              </div>
            </div>
        </body>
        </html>
                


        <?php
    }
    
        public function load_scripts(){?>
    
        <script>
        
            jQuery(document).ready(function($) {
              // Event handler for the form submission
              $('#myForm').submit(function(event) {
                event.preventDefault(); // Prevent form submission
                
                var nonce = $('#nonceField').val();
            
                // Send POST request using AJAX
                $.ajax({
                  url:'<?php echo get_rest_url(null, '/formData/v1/send-comment');?>', // WordPress AJAX handler URL
                  type: 'POST',
                   data: {
                    action: 'insert_data', // Name of the AJAX action
                    nonce: nonce, // WordPress Nonce
                    name: $('#nameField').val(), // Value from the name field
                    post: $('#postField').val() // Value from the post field
                  },
                  success: function(response) {
                    // Handle successful response
                    console.log(response); // Output "it worked" in the browser console
                  },
                  error: function(error) {
                    // Handle error
                    console.log('AJAX request failed');
                  }
                });
              });
            });

        
        </script>
        
    <?php }
    
        public function register_rest_api(){
        
        register_rest_route('/formData/v1', '/send-comment', array(
            
            'methods'=>'POST',
            'callback'=>array($this, 'insert_data_handler')
            
            ));
    }
    


        // AJAX action handler function
        function insert_data_handler() {
          // Check if it is a POST request and verify the nonce
          if (wp_verify_nonce($_POST['nonce'], 'insert_data_nonce') && $_SERVER['REQUEST_METHOD'] === 'POST') {
            // Get the submitted data
            $name = sanitize_text_field($_POST['name']);
            $post = sanitize_text_field($_POST['post']);
        
            // Perform validation or additional processing if needed
        
            // Insert data into the WordPress database
            $data = array(
              'post_title'   => $name,
              'post_content' => $post,
              'post_status'  => 'publish',
              'post_type'    => 'post'
            );
            $post_id = wp_insert_post($data);
        
            if ($post_id) {
              // Data insertion successful
              echo 'Data inserted successfully!';
            } else {
              // Data insertion failed
              echo 'Failed to insert data.';
            }
          } else {
            // Invalid nonce or request method
            echo 'Invalid request.';
          }
        
          // Always exit after handling the AJAX request
          wp_die();
        }

    
}
new CommentApp;