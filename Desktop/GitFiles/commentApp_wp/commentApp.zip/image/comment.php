<?php
class CommentApp{
    
    public function __construct(){
        add_action('init', array($this, 'create_comment'));
        add_action('up_enqueue_script', array($this, 'load_assets'));
    }
    
    public function create_comment(){
        $args = array(
            'public'=> true,
            'has_archive' => true,
            'supports'=> array('title'),
            'exclude_from_search' => true,
            'publicly_queriable' => false,
            'capability' => 'manage_options',
            'labels'=> array(
                'name' => 'Comment App',
                'singular_name'=> 'comment form'
                ),
                'menu_icon'=>'dashicons-admin-comments',
      );
      register_post_type('CommentApp', $args);
    }
    
    public function load_assets(){
            wp_enqueue_style(
    'style',
    plugin_dir_url(__FILE__).'css/style.css',
    array(),
    1,
    'all'
    );
    }

    
}
new CommentApp;